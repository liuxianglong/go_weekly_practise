package types

import "time"

type StringAlias string

type DateOnly time.Time
