package container

var App = NewContainer()
